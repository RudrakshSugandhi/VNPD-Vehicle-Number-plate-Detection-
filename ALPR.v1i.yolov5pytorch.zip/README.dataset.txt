# ALPR > 2022-10-25 3:22pm
https://universe.roboflow.com/object-detection/alpr-bfdif

Provided by Roboflow
License: MIT

